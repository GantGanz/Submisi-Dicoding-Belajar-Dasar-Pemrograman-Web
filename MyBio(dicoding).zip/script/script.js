alert('Selamat Datang di web saya, untuk kenyamanan pengguna, silahkan matikan adblock dan gunakanlah browser Google Chrome :)');
alert('Bercanda, nggak usah matiin adblock :v')